export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyArLx8hyOLnkD10rowW9rnrm_4go6gJ70k",
    authDomain: "la-trat-toria-1.firebaseapp.com",
    databaseURL: "https://la-trat-toria-1.firebaseio.com",
    projectId: "la-trat-toria-1",
    storageBucket: "la-trat-toria-1.appspot.com",
    messagingSenderId: "727206966591"
  }
};
